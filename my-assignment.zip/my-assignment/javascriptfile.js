
function f2(){
var modal = document.getElementById("myModal");

var btn = document.getElementById("myBtn");
var span = document.getElementsByClassName("close")[0];
btn.onclick = function() {
  modal.style.display = "block";
}
span.onclick = function() {
  modal.style.display = "none";
}
window.onclick = function(event) {
    if (event.target == modal) {
      modal.style.display = "none";
    }
  }
}


function function1(id)
{
var curr,x,i;
x = document.getElementsByClassName("imgvect");
curr=id;
for(i=0;i<x.length;i++)
{
    x[i].style.backgroundColor = "#ffffff";  
    x[i].style.color ="#979797";  
}
document.getElementById(curr).style.color='#e20074';
document.getElementById(curr).style.backgroundColor='#fce6f1';

}




   /*sidepanel*/ 
function openNav() {
    document.getElementById("mySidepanel").style.width = "300px";
  }
  
  function closeNav() {
    document.getElementById("mySidepanel").style.width = "0";
  }



  /*lifecycle menu*/
  function lifecycle_menu() {
    document.getElementById("lifeDropdown").classList.toggle("show");
  }
  
  window.onclick = function(event) {
    if (!event.target.matches('.header-text')) {
      var dropdowns = document.getElementsByClassName("life-dropdown-content");
      var i;
      for (i = 0; i < dropdowns.length; i++) {
        var openDropdown = dropdowns[i];
        if (openDropdown.classList.contains('show')) {                                      
          openDropdown.classList.remove('show');
        }
      }
    }
    if (!event.target.matches('.group')) {
        var dropdowns = document.getElementsByClassName("jason-dropdown-content");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
          var openDropdown = dropdowns[i];
          if (openDropdown.classList.contains('life-show')) {                                      
            openDropdown.classList.remove('life-show');
          }
        }
      }




  }

  /* jason menu*/

  function jason_menu() {
    document.getElementById("jasonDropdown").classList.toggle("life-show");
  }





